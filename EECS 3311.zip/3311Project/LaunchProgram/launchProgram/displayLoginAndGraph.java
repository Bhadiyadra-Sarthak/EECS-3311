package launchProgram;

import java.awt.EventQueue;

import login.Login_builder;

public class displayLoginAndGraph {
	
	
	
	
/**
 * Main program that launches login display and with correct credentials launches the GUI for analysis.
 * @param args
 */
public static void main(String[] args){

		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
				try {
					Login_builder window = new Login_builder();
					window.getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
