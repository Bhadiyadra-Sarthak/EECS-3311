package projectTesting;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Vector;

import javax.swing.JComboBox;

import org.junit.jupiter.api.Test;

public class testSelectAnalysis {
	@Test
	void test_analysisSelection_10() {
		Vector<String> name = new Vector<String>();
		name.add("Total Population vs Energy Use");
		JComboBox<String> analysisList = new JComboBox<String>(name);
		analysisList.setSelectedItem(name);
		String analysis = "Total Population vs Energy Use";
		boolean correctSelection = analysisList.getSelectedItem().toString().equals(analysis) ;
		assertEquals(true, correctSelection);
	}
	@Test
	void test_analysisSelection_11() {
		Vector<String> name = new Vector<String>();
		name.add("Total Population vs Energy Use");
		JComboBox<String> analysisList = new JComboBox<String>(name);
		analysisList.setSelectedItem(name);
		String analysis = "Lending Interest rates vs Real Interest Rates vs Difference betweeen the two";
		boolean correctSelection = analysisList.getSelectedItem().toString().equals(analysis) ;
		assertEquals(false, correctSelection);
	}
	@Test
	void test_analysisSelection_12() {
		Vector<String> name = new Vector<String>();
		JComboBox<String> analysisList = new JComboBox<String>(name);
		analysisList.setSelectedItem(name);
		String analysis = "Lending Interest rates vs Real Interest Rates vs Difference betweeen the two";
		boolean correctSelection = true;
		if (analysisList.getSelectedItem() == null) {
			correctSelection = false;
		}
		else {
			correctSelection = analysisList.getSelectedItem().toString().equals(analysis) ;
		}
		
		assertEquals(false, correctSelection);
	}
	@Test
	void test_analysisSelection_13() {
		// First selection being done
		Vector<String> name = new Vector<String>();
		name.add("Total Population vs Energy use");
		JComboBox<String> analysisList = new JComboBox<String>(name);
		analysisList.setSelectedIndex(0);
	
		// Second selection being done
		Vector<String> otherName = new Vector<String>();
		otherName.add("Lending Interest rates vs Real Interest Rates vs Difference betweeen the two");
		analysisList = new JComboBox<String>(otherName);
		analysisList.setSelectedIndex(0);
		
		// Check if second selection is the one that is selected...
		String analysis = "Lending Interest rates vs Real Interest Rates vs Difference betweeen the two";
		boolean correctSelection = analysisList.getSelectedItem().toString().equals(analysis) ;
		assertEquals(true, correctSelection);
	}
	@Test
	void test_analysisSelection_14() {
		// Selection being done
		Vector<String> name = new Vector<String>();
		name.add("Total Population vs Energy use");
		name.add("Air Pollution Mean Annual Exposure vs Forest Area");
		name.add("Lending Interest rates vs Real Interest Rates vs Difference betweeen the two");
		JComboBox<String> analysisList = new JComboBox<String>(name);
		analysisList.setSelectedIndex(2);
		
		String analysis = "Lending Interest rates vs Real Interest Rates vs Difference betweeen the two";
		boolean correctSelection = analysisList.getSelectedItem().toString().equals(analysis) ;
		assertEquals(true, correctSelection);
	}
}
