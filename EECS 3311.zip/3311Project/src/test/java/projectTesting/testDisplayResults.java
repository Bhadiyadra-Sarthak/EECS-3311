package projectTesting;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.Component;
import java.util.HashMap;
import java.util.Vector;

import javax.swing.JComboBox;
import javax.swing.JPanel;

import org.junit.jupiter.api.Test;

import dataFetching.Data;
import dataFetching.FakeFetch;
import dataFetching.Proxy;
import gui.Maingui;

public class testDisplayResults {
	@Test
	void test_displayResults_35() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createScatter(charts);
		Component[] components = charts.getComponents();
		test.createScatter(charts);
		Component[] recallComponents = charts.getComponents();
		boolean noDuplicates = true;
		for (int i = 0; i < recallComponents.length; i++) {
			noDuplicates = noDuplicates && (components[i] == recallComponents[i]);
		}
		assertEquals(true, noDuplicates);
	}
	@Test
	void test_displayResults_36() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createBar(charts);
		Component[] components = charts.getComponents();
		test.createBar(charts);
		Component[] recallComponents = charts.getComponents();
		boolean noDuplicates = true;
		for (int i = 0; i < recallComponents.length; i++) {
			noDuplicates = noDuplicates && (components[i] == recallComponents[i]);
		}
		assertEquals(true, noDuplicates);
	}
	@Test
	void test_displayResults_37() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createLine(charts);
		Component[] components = charts.getComponents();
		test.createLine(charts);
		Component[] recallComponents = charts.getComponents();
		boolean noDuplicates = true;
		for (int i = 0; i < recallComponents.length; i++) {
			noDuplicates = noDuplicates && (components[i] == recallComponents[i]);
		}
		assertEquals(true, noDuplicates);
	}
	@Test
	void test_displayResults_38() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createReport(charts);
		Component[] components = charts.getComponents();
		test.createReport(charts);
		Component[] recallComponents = charts.getComponents();
		boolean noDuplicates = true;
		for (int i = 0; i < recallComponents.length; i++) {
			noDuplicates = noDuplicates && (components[i] == recallComponents[i]);
		}
		assertEquals(true, noDuplicates);
	}
	@Test
	void test_displayResults_39() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createScatter(charts);
		Component[] components = charts.getComponents();
		
		// Arbitrary values in textbox to run execution, which is expected to remove all components
		Vector<String> temp = new Vector<String>();
		temp.add("Total Population vs Energy Use");
		JComboBox<String> analysis = new JComboBox<String>(temp);
		temp = new Vector<String>();
		temp.add("United States");
		JComboBox<String> country = new JComboBox<String>(temp);
		temp = new Vector<String>();
		temp.add("2002");
		JComboBox<String> startYear = new JComboBox<String>(temp); 
		temp = new Vector<String>();
		temp.add("2007");
		JComboBox<String> endYear = new JComboBox<String>(temp); 
		test.runExecution(analysis, country, null, startYear, endYear);
		
		// Compare components, they should not be the same...
		assertEquals(true, charts.getComponents() != components);
	}
	
	//Harmans work below: 
	
	
	// First 4 tests are for if adding works for all 4 types of graphs
	
	@Test
	void test_displayResults_40() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createReport(charts);
		Component[] components = charts.getComponents();
		boolean exists = false;
		if(components.length > 0){
			exists = true;
		}
		assertEquals(true, exists);
	}
	
	@Test
	void test_displayResults_41() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createBar(charts);
		Component[] components = charts.getComponents();
		boolean exists = false;
		if(components.length > 0){
			exists = true;
		}
		assertEquals(true, exists);
	}
	
	@Test
	void test_displayResults_42() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createLine(charts);
		Component[] components = charts.getComponents();
		boolean exists = false;
		if(components.length > 0){
			exists = true;
		}
		assertEquals(true, exists);
	}
	
	@Test
	void test_displayResults_43() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createScatter(charts);
		Component[] components = charts.getComponents();
		boolean exists = false;
		if(components.length > 0){
			exists = true;
		}
		assertEquals(true, exists);
	}

	// Next 4 tests are for if removing works for all 4 types of graphs
	
	@Test
	void test_displayResults_44() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createReport(charts);
		Component[] components = charts.getComponents();
		boolean exists = false;
		for(Component component: components) {
			if(test.removeReport == component) {
				charts.remove(test.removeReport);
			}
		}
		components = charts.getComponents();
		if(components.length == 0){
			exists = true;
		}
		assertEquals(true, exists);
	}
	
	@Test
	void test_displayResults_45() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createBar(charts);
		Component[] components = charts.getComponents();
		boolean exists = false;
		for(Component component: components) {
			if(test.removeBar == component) {
				charts.remove(test.removeBar);
			}
		}
		components = charts.getComponents();
		if(components.length == 0){
			exists = true;
		}
		assertEquals(true, exists);
	}
	
	@Test
	void test_displayResults_46() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createLine(charts);
		Component[] components = charts.getComponents();
		boolean exists = false;
		for(Component component: components) {
			if(test.removeLine == component) {
				charts.remove(test.removeLine);
			}
		}
		components = charts.getComponents();
		if(components.length == 0){
			exists = true;
		}
		assertEquals(true, exists);
	}
	
	@Test
	void test_displayResults_47() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createScatter(charts);
		Component[] components = charts.getComponents();
		boolean exists = false;
		for(Component component: components) {
			if(test.removeScatter == component) {
				charts.remove(test.removeScatter);
			}
		}
		components = charts.getComponents();
		if(components.length == 0){
			exists = true;
		}
		assertEquals(true, exists);
	}
	
	// check if empty chart works (nothing is added)
	
	@Test
	void test_displayResults_48() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		Component[] components = charts.getComponents();
		boolean exists = false;
		if(components.length == 0){
			exists = true;
		}
		assertEquals(true, exists);
	}
	
	// check if all the charts are added
	
	@Test
	void test_displayResults_49() {
		JPanel charts = new JPanel();
		Maingui test = new Maingui();
		
		// Arbitrary data to test creation of graph and display
		test.initializeGraphData("Canada", "Total Population vs Energy Use", "2004", "2006");
		test.createScatter(charts);
		test.createBar(charts);
		test.createLine(charts);
		test.createReport(charts);
		Component[] components = charts.getComponents();
		boolean exists = false;
		if(components.length == 4){
			exists = true;
		}
		assertEquals(true, exists);
	}
	
	
}
