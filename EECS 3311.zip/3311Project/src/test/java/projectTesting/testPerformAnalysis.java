package projectTesting;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.HashMap;

import org.junit.jupiter.api.Test;

import dataFetching.*;

public class testPerformAnalysis {
	@Test
	void test_performAnalysis_30() {
		FakeFetch proxy = new Proxy();
		HashMap<Integer, Double> testFetchResults = proxy.request(new Data("CAN", "Total Population", "2004", "2006"));
		int startYear = 2004;
		boolean fetchCorrect = true;
		Double[] totalPop = {31940655.0, 32243753.0, 32571174.0};
		for (int i = 0; i < testFetchResults.size(); i++) {
			fetchCorrect = fetchCorrect && Double.compare(testFetchResults.get(startYear + i), totalPop[i]) == 0;
		}
		assertEquals(true, fetchCorrect);
	}
	@Test
	void test_performAnalysis_31() {
		FakeFetch proxy = new Proxy();
		HashMap<Integer, Double> testFetchResults = proxy.request(new Data("CAN", "Total Population", "2004", "2006"));
		int startYear = 2004;
		boolean fetchCorrect = true;
		Double[] totalPop = {3.1, 3.4, 3.2};
		for (int i = 0; i < testFetchResults.size(); i++) {
			fetchCorrect = fetchCorrect && Double.compare(testFetchResults.get(startYear + i), totalPop[i]) == 0;
		}
		assertEquals(false, fetchCorrect);
	}
	@Test
	void test_performAnalysis_32() {
		FakeFetch proxy = new Proxy();
		HashMap<Integer, Double> testFetchResults = proxy.request(new Data("CAN", "Agricultural irrigated land (% of total agricultural land)", "2004", "2006"));
		int startYear = 2004;
		boolean fetchCorrect = true;
		Double[] totalPop = {0.0, 1.37, 0.0};
		for (int i = 0; i < testFetchResults.size(); i++) {
			fetchCorrect = fetchCorrect && Double.compare(testFetchResults.get(startYear + i), totalPop[i]) == 0;
		}
		assertEquals(true, fetchCorrect);
	}
	@Test
	void test_performAnalysis_33() {
		FakeFetch proxy = new Proxy();
		HashMap<Integer, Double> testFetchResults = proxy.request(new Data("CAN", "Energy use (kg of oil equivalent per capita)", "2004", "2006"));
		int startYear = 2004;
		boolean fetchCorrect = true;
		Double[] energyUse = {8455.55, 8422.03, 8239.95};
		for (int i = 0; i < testFetchResults.size(); i++) {
			fetchCorrect = fetchCorrect && Double.compare(testFetchResults.get(startYear + i), energyUse[i]) == 0;
		}
		assertEquals(true, fetchCorrect);
	}
	@Test
	void test_performAnalysis_34() {
		FakeFetch proxy = new Proxy();
		HashMap<Integer, Double> testFetchResults = proxy.request(new Data("ID", "School enrollment, secondary (% gross)", "2018", "2020"));
		int startYear = 2018;
		boolean fetchCorrect = true;
		Double[] totalPop = {88.91, 0.0, 0.0};
		for (int i = 0; i < testFetchResults.size(); i++) {
			fetchCorrect = fetchCorrect && Double.compare(testFetchResults.get(startYear + i), totalPop[i]) == 0;
		}
		assertEquals(true, fetchCorrect);
	}
}
