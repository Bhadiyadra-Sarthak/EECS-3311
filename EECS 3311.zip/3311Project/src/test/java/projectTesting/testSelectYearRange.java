package projectTesting;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Vector;

import javax.swing.JComboBox;

import org.junit.jupiter.api.Test;

public class testSelectYearRange {
	@Test
	void test_yearSelection_15() {
		// Checks whether the two selected years are selected correctly...
		Vector<String> testYears = new Vector<String>();
		testYears.add("2001");
		testYears.add("2005");
		JComboBox<String> fromList = new JComboBox<String>(testYears);
		JComboBox<String> toList = new JComboBox<String>(testYears);
		fromList.setSelectedIndex(0);
		toList.setSelectedIndex(1);
		String start = "2001";
		String end = "2005";
		boolean correctSelection = false;
		if (Integer.parseInt(fromList.getSelectedItem().toString()) > Integer.parseInt(toList.getSelectedItem().toString())) {
			correctSelection = false;
		}
		else {
			correctSelection = (start.equals(fromList.getSelectedItem().toString()) && end.equals(toList.getSelectedItem().toString()));
		}
		assertEquals(true, correctSelection);
	}
	@Test
	void test_yearSelection_16() {
		// Checks whether the two selected years are selected correctly...
		Vector<String> testYears = new Vector<String>();
		testYears.add("2001");
		testYears.add("2001");
		JComboBox<String> fromList = new JComboBox<String>(testYears);
		JComboBox<String> toList = new JComboBox<String>(testYears);
		fromList.setSelectedIndex(0);
		toList.setSelectedIndex(1);
		String start = "2001";
		String end = "2001";
		boolean correctSelection = false;
		if (Integer.parseInt(fromList.getSelectedItem().toString()) > Integer.parseInt(toList.getSelectedItem().toString())) {
			correctSelection = false;
		}
		else {
			correctSelection = (start.equals(fromList.getSelectedItem().toString()) && end.equals(toList.getSelectedItem().toString()));
		}
		assertEquals(true, correctSelection);
	}
	@Test
	void test_yearSelection_17() {
		// Checks whether the two selected years are selected correctly...
		Vector<String> testYears = new Vector<String>();
		testYears.add("2010");
		testYears.add("2001");
		JComboBox<String> fromList = new JComboBox<String>(testYears);
		JComboBox<String> toList = new JComboBox<String>(testYears);
		fromList.setSelectedIndex(0);
		toList.setSelectedIndex(1);
		String start = "2010";
		String end = "2001";
		boolean correctSelection = false;
		if (Integer.parseInt(fromList.getSelectedItem().toString()) > Integer.parseInt(toList.getSelectedItem().toString())) {
			correctSelection = false;
		}
		else {
			correctSelection = (start.equals(fromList.getSelectedItem().toString()) && end.equals(toList.getSelectedItem().toString()));
		}
		assertEquals(false, correctSelection);
	}
	@Test
	void test_yearSelection_18() {
		// Checks whether the two selected years are selected correctly...
		Vector<String> testYears = new Vector<String>();
		testYears.add("1700");
		testYears.add("2010");
		JComboBox<String> fromList = new JComboBox<String>(testYears);
		JComboBox<String> toList = new JComboBox<String>(testYears);
		fromList.setSelectedIndex(0);
		toList.setSelectedIndex(1);
		String start = "1700";
		String end = "2010";
		boolean correctSelection = false;
		if (Integer.parseInt(fromList.getSelectedItem().toString()) > Integer.parseInt(toList.getSelectedItem().toString()) 
				|| Integer.parseInt(fromList.getSelectedItem().toString()) < 1995 
				|| Integer.parseInt(toList.getSelectedItem().toString()) > 2018) {
			correctSelection = false;
		}
		else {
			correctSelection = (start.equals(fromList.getSelectedItem().toString()) && end.equals(toList.getSelectedItem().toString()));
		}
		assertEquals(false, correctSelection);
	}
	@Test
	void test_yearSelection_19() {
		// Checks whether the two selected years are selected correctly...
		Vector<String> testYears = new Vector<String>();
		testYears.add("2010");
		testYears.add("2019");
		JComboBox<String> fromList = new JComboBox<String>(testYears);
		JComboBox<String> toList = new JComboBox<String>(testYears);
		fromList.setSelectedIndex(0);
		toList.setSelectedIndex(1);
		String start = "2010";
		String end = "2019";
		boolean correctSelection = false;
		if (Integer.parseInt(fromList.getSelectedItem().toString()) > Integer.parseInt(toList.getSelectedItem().toString()) 
				|| Integer.parseInt(fromList.getSelectedItem().toString()) < 1995 
				|| Integer.parseInt(toList.getSelectedItem().toString()) > 2018) {
			correctSelection = false;
		}
		else {
			correctSelection = (start.equals(fromList.getSelectedItem().toString()) && end.equals(toList.getSelectedItem().toString()));
		}
		assertEquals(false, correctSelection);
	}
}
