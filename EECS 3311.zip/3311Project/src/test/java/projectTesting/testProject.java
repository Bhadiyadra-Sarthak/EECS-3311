package projectTesting;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import gui.setCountries;
import login.system;

class testProject {

	@Test
	void test_login_00() {
		system checkUsername = new system();
		String username = "admin";
		String password = "password";
		boolean answer = checkUsername.checkIfDatabase(username, password);
		assertEquals(true, answer);
	}
	
	@Test
	void test_login_01_checkingCapitalization() {
		system checkUsername = new system();
		String username = "Admin";
		String password = "password";
		boolean answer = checkUsername.checkIfDatabase(username, password);
		assertEquals(false, answer);
	}
	
	@Test
	void test_login_02_checkingRandomUsername() {
		system checkUsername = new system();
		String username = "random";
		String password = "password";
		boolean answer = checkUsername.checkIfDatabase(username, password);
		assertEquals(false, answer);
	}
	
	@Test
	void test_login_03_checkingEmptyLogin() {
		system checkUsername = new system();
		String username = "";
		String password = "";
		boolean answer = checkUsername.checkIfDatabase(username, password);
		assertEquals(false, answer);
	}
	
	@Test
	void test_login_04_checkingAnotherAdmin() {
		system checkUsername = new system();
		String username = "Jonathan";
		String password = "pass123";
		boolean answer = checkUsername.checkIfDatabase(username, password);
		assertEquals(true, answer);
	}
	
	
	@Test
	void test_country_05_checkingIfCountryInDropDown() {
		setCountries settingCountries = new setCountries();
		String country = "United States";
		boolean hasCountry = settingCountries.countriesInDropDown(country);
		assertEquals(true, hasCountry);
	}

	@Test
	void test_country_06_notInJSONFile() {
		setCountries settingCountries = new setCountries();
		String country = "Zimbabwe"; //removed from json file
		boolean hasCountry = settingCountries.checkIfCountryAllowed(country);
		assertEquals(false, hasCountry);
	}
	
	@Test
	void test_country_07_inJSONFile() {
		setCountries settingCountries = new setCountries();
		String country = "Canada"; //Canada is in the Json file
		boolean hasCountry = settingCountries.checkIfCountryAllowed(country);
		assertEquals(true, hasCountry);
	}
	
	
	@Test
	void test_country_08_inJSONFile() {
		setCountries settingCountries = new setCountries();
		String country = "Albania"; //Albania is in the Json file
		boolean hasCountry = settingCountries.checkIfCountryAllowed(country);
		assertEquals(true, hasCountry);
	}
	
	@Test
	void test_country_09_inJSONFile() {
		setCountries settingCountries = new setCountries();
		String country = "China"; //China is in the Json file
		boolean hasCountry = settingCountries.checkIfCountryAllowed(country);
		assertEquals(true, hasCountry);
	}
	testSelectAnalysis test = new testSelectAnalysis();
}
