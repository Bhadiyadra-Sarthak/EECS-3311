package dataFetching;

import java.util.ArrayList;
import java.util.HashMap;

public abstract class FakeFetch {
	public abstract HashMap<Integer, Double> request(Data data);
	public abstract HashMap<Integer, Double> request(Data data, ArrayList<HashMap <Integer, Double>> temp);
}
