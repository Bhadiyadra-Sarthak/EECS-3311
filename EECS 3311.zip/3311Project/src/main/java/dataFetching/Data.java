package dataFetching;

public class Data {
	// Variables
	private String country;
	private String indicatorString;
	private int startYear;
	private int endYear;
	
	
	// Constructors methods
	public Data(String country, String indicatorString, String startYear, String endYear) {
		this.country = country;
		this.indicatorString = indicatorString;
		this.startYear = Integer.parseInt(startYear);
		this.endYear = Integer.parseInt(endYear);
	}
	
	// Return methods
	public String getCountry() {
		return country;
	}
	public String getIndicatorString() {
		return indicatorString;
	}
	public int getStartYear() {
		return startYear;
	}
	public int getEndYear() {
		return endYear;
	}
	
	// Computational methods
}
