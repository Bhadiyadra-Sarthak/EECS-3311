package dataFetching;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import java.util.*;

public class Fetch {
	// Variables
	private String urlString;
	private Data data;
	private HashMap<String, String> indicators = new HashMap<String, String>();
	private HashMap<Integer, Double> values = new HashMap<Integer, Double>();
		
	// Constructors methods
	public Fetch(Data data) {
		this.data = data;
		buildIndicators();
	}
		
	// Return methods
	public int getResponse(HttpURLConnection connection) throws IOException {
            return connection.getResponseCode();    
    }
	
	public void getAnalysisData(URL url) throws IOException {
		 	
		String inline = "";
		Scanner sc = new Scanner(url.openStream());
		
		while (sc.hasNext()) {
			inline += sc.nextLine();
		}
		sc.close();
		
		JsonArray jsonArray = new JsonParser().parse(inline).getAsJsonArray();
//		if (jsonArray.get(0).getAsJsonArray().get(0).getAsJsonObject().get("value").getAsString().equals("The provided parameter value is not valid")) {
//			//
//		}
		int sizeOfResults = jsonArray.get(1).getAsJsonArray().size();
		for (int i = 0; i < sizeOfResults; i++) {
			if (jsonArray.get(1).getAsJsonArray().get(i).getAsJsonObject().get("value").isJsonNull()) {
				values.put(data.getEndYear() - i, 0.00);
			}
				
			else {
				Double value = jsonArray.get(1).getAsJsonArray().get(i).getAsJsonObject().get("value")
						.getAsDouble();
				BigDecimal bd = new BigDecimal(value).setScale(2, RoundingMode.HALF_UP);
				values.put(data.getEndYear() - i, bd.doubleValue());
				
			}
		}
	}
		
	public void getAnalysisData(URL url, ArrayList<HashMap <Integer, Double>> temp) throws IOException {
		 	
		String inline = "";
		Scanner sc = new Scanner(url.openStream());
			
		while (sc.hasNext()) {
			inline += sc.nextLine();
		}
		sc.close();
			
		JsonArray jsonArray = new JsonParser().parse(inline).getAsJsonArray();
		int sizeOfResults = jsonArray.get(1).getAsJsonArray().size();
			
		for (int i = 0; i < sizeOfResults; i++) {
			if (jsonArray.get(1).getAsJsonArray().get(i).getAsJsonObject().get("value").isJsonNull()) {
				values.put(data.getEndYear() - i, 0.00);
			}
					
			else {
				Double value = jsonArray.get(1).getAsJsonArray().get(i).getAsJsonObject().get("value")
						.getAsDouble();
				value /= 100.0;
				value *= temp.get(0).get(data.getEndYear() - i);
				BigDecimal bd = new BigDecimal(value).setScale(2, RoundingMode.HALF_UP);
				values.put(data.getEndYear() - i, bd.doubleValue());
					
			}
		}
		
//		// Testing the values being stored
//		for (Map.Entry<Integer, Double> entry : values.entrySet()) {
//		    System.out.println("The year is... " + entry.getKey() + " the values is... " + String.format("%.2f", entry.getValue()));
//		}
	}
	
	// Computational methods
	
	// Build set indicators with corresponding ID
	// Future build, take ID from input using website extraction...
	public void buildIndicators() {
		indicators.put("Total Population", "SP.POP.TOTL");
		indicators.put("Energy use (kg of oil equivalent per capita)", "EG.USE.PCAP.KG.OE");
		indicators.put("CO2 emissions (metric tons per capita)", "EN.ATM.CO2E.PC");
		indicators.put("GDP per capita (current US$)", "NY.GDP.PCAP.CD");
		indicators.put("Alternative and nuclear energy (% of total energy use)", "EG.USE.COMM.CL.ZS");
		indicators.put("Government expenditure on education, total (% of GDP)", "SE.XPD.TOTL.GD.ZS");
		indicators.put("Research and development expenditure (% of GDP)", "GB.XPD.RSDV.GD.ZS");
		indicators.put("PM2.5 air pollution, mean annual exposure (as micrograms per cubic meter)", "EN.ATM.PM25.MC.M3");
		indicators.put("Forest area (% of land area)", "AG.LND.FRST.ZS");
		indicators.put("Surface area (sq. km)", "AG.SRF.TOTL.K2");
		indicators.put("Agricultural land (% of land area)", "AG.LND.AGRI.ZS");
		indicators.put("Agricultural irrigated land (% of total agricultural land)", "AG.LND.IRIG.AG.ZS");
		indicators.put("Lending interest rate (%)", "FR.INR.LEND");
		indicators.put("Real interest rate (%)", "FR.INR.RINR");
		indicators.put("Population ages 15-64 (% of total population)", "SP.POP.1564.TO.ZS");
		indicators.put("School enrollment, secondary (% gross)", "SE.SEC.ENRR");
		indicators.put("Fuel exports (% of merchandise exports)", "TX.VAL.FUEL.ZS.UN");
		indicators.put("GDP (current US$)", "NY.GDP.MKTP.CD");
 
		
		
	}
	
	public HashMap<Integer, Double> request() {
		buildURL();
		startConnection();
		return values;
	}
	public HashMap<Integer, Double> request(ArrayList<HashMap <Integer, Double>> temp) {
		buildURL();
		startConnection(temp);
		return values;
	}
	public void buildURL() {
		
		// Builds the url with the given data, extracting ID from string
		
		urlString =  String.format(
				"http://api.worldbank.org/v2/country/%s/indicator/%s?date=%s:%s&format=json", data.getCountry(), 
				indicators.get(data.getIndicatorString()), data.getStartYear(), data.getEndYear());
		//System.out.println(urlString);
	}
	
	public void startConnection() {
        try {
        	URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            if (getResponse(conn) == 200) {
                getAnalysisData(url);
            }
        }
        catch (IOException e){

        }
		
    }
	
	public void startConnection(ArrayList<HashMap <Integer, Double>> temp) {
        try {
        	URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            if (getResponse(conn) == 200) {
                getAnalysisData(url, temp);
            }
        }
        catch (IOException e){

        }
		
    }
}
