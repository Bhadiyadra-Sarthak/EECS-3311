package dataFetching;

import java.util.HashMap;


import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.XYSeriesCollection;

import dataForGraphs.*;

public class FetchConsole {

	public static void main(String[] args) {
		//FakeFetch proxy = new Proxy();
		//HashMap<Integer, Double> output = proxy.request(new Data("CAN", "Total Population", "2000", "2001"));
		//System.out.println("Testing return of hashmap and printing from console... " + String.format("%.2f", output.get(2000)));
		FakeFetch proxy = new Proxy();
		proxy.request(new Data("ID", "School enrollment, secondary (% gross)", "2018", "2020"));
		
//		BuilderForGraphs buildTest1 = new BuilderForGraphs("Canada", "Total Population vs Energy use", "2000", "2010");
//		BuilderForGraphs buildTest2 = new BuilderForGraphs("Canada", "Surface Area vs Agricultural Land vs Agricultural Irrigated Land", "2000", "2010");
//		GraphCreation graphTest = new GraphCreation();
//		
//		DefaultCategoryDataset testDataSet1 = buildTest2.generateBarGraph();
//		
//		
//		
//		DefaultCategoryDataset testDataSet2 = graphTest.createBar(buildTest2.performRatio(), buildTest2.getIndicators(), buildTest2.getStartYear());
//		XYSeriesCollection testDataset3 = buildTest2.generateLineGraph();
		return;
	}

}


