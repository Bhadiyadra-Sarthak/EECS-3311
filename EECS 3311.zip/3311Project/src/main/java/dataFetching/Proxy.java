package dataFetching;

import java.util.ArrayList;
import java.util.HashMap;

public class Proxy extends FakeFetch{
	
	// Variables
	private Fetch fetch;
	
	// Void method
	public HashMap<Integer, Double> request(Data data) {
		fetch = new Fetch(data);
		return fetch.request();
		
	}
	public HashMap<Integer, Double> request(Data data, ArrayList<HashMap <Integer, Double>> temp) {
		fetch = new Fetch(data);
		return fetch.request(temp);
		
	}
}
