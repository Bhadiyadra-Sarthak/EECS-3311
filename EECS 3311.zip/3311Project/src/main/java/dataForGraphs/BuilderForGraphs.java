package dataForGraphs;

import java.util.ArrayList;

import java.util.HashMap;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYSeriesCollection;

import analysis.Context;
import analysis.DifferenceAnalysis;
import analysis.RatioAnalysis;
import dataFetching.*;
import gui.setCountries;

public class BuilderForGraphs {
	
	// VARIABLES
	private String country;
	private String startYear;
	private String endYear;
	private String analysis;
	private String xAxis;
	private String yAxis;
	
	private String[] indicators;
	private ArrayList<HashMap <Integer, Double>> valueArray;
	private DefaultCategoryDataset barGraphDataset;
	private XYSeriesCollection lineGraphDataset;
	private TimeSeriesCollection scatterGraphDataset;
	private String reportGraphDataset;
	private setCountries getAcronymList;
	
	/*
	 * 		indicators.put("Total Population", "SP.POP.TOTL");
		indicators.put("Energy use (kg of oil equivalent per capita)", "EG.USE.PCAP.KG.OE");
		indicators.put("CO2 emissions (metric tons per capita)", "EN.ATM.CO2E.PC");
		indicators.put("GDP per capita (current US$)", "NY.GDP.PCAP.CD");
		indicators.put("Alternative and nuclear energy (% of total energy use)", "EG.USE.COMM.CL.ZS");
		indicators.put("Government expenditure on education, total (% of GDP)", "SE.XPD.TOTL.GD.ZS");
		indicators.put("Research and development expenditure (% of GDP)", "GB.XPD.RSDV.GD.ZS");
		indicators.put("PM2.5 air pollution, mean annual exposure (as micrograms per cubic meter)", "EN.ATM.PM25.MC.M3");
		indicators.put("Forest area (% of land area)", "AG.LND.FRST.ZS");
		indicators.put("Surface area (sq. km)", "AG.SRF.TOTL.K2");
		indicators.put("Agricultural land (% of land area)", "AG.LND.AGRI.ZS");
		indicators.put("Agricultural irrigated land (% of total agricultural land)", "AG.LND.IRIG.AG.ZS");
		indicators.put("Lending interest rate (%)", "FR.INR.LEND");
		indicators.put("Real interest rate (%)", "FR.INR.RINR");
		indicators.put("Population ages 15-64 (% of total population)", "SP.POP.1564.TO.ZS");
		indicators.put("Literacy rate, adult total (% of people ages 15 and above)", "SE.ADT.1524.LT.ZS");
	 */
	public BuilderForGraphs(String country, String analysis, String startYear, String endYear)
	{
		HashMap<String, String> countriesToAcronym = countryToAcronym();
		getAcronymList = new setCountries();
		this.country = getAcronymList.returnAcronym(country);
		//this.country = countriesToAcronym.get(country);
		this.startYear = startYear;
		this.endYear = endYear;
		this.analysis = analysis;
		
		this.setIndicators(analysis);
		
		
	}
	
	public DefaultCategoryDataset generateBarGraph() {
		return this.barGraphDataset;
	}
	
	public XYSeriesCollection generateLineGraph() {
		return this.lineGraphDataset;
	}
	public TimeSeriesCollection generateScatterGraph() {
		return this.scatterGraphDataset;
	}
	public String generateReport()
	{
		return this.reportGraphDataset;
	}
	
	
	
	public void setIndicators(String input)
	{
		String analysis = input.toLowerCase();
		GraphCreation graph = new GraphCreation();
		if (analysis.equals(("Total Population vs Energy Use").toLowerCase()))
		{
			indicators = new String[2];
			indicators[0] =  "Total Population";
			indicators[1] = "Energy use (kg of oil equivalent per capita)";
			xAxis = "Number of People";
			yAxis = "kg of oil equivalent per capita";
			valueArray = performAnnualChange();
			barGraphDataset = graph.createBar(getValueArray(), getIndicators(), getStartYear());
			lineGraphDataset = graph.createLine(getValueArray(), getIndicators(), getEndYear());
			scatterGraphDataset = graph.createScatter(getValueArray(), getIndicators(), getEndYear());
			reportGraphDataset = graph.createReport(getValueArray(), getIndicators(), getEndYear(), getAnalysis(), getStartYear());
		}
		else if (analysis.equals(("Ratio of GDP per Capita and CO2 Emissions").toLowerCase()))
		{
			indicators = new String[2];
			indicators[1] =  "CO2 emissions (metric tons per capita)";
			indicators[0] = "Energy use (kg of oil equivalent per capita)";
			xAxis = "metric tons per capita";
			yAxis = "kg of oil equivalent per capita";
			valueArray = performRatio();
			indicators = new String[1];
			indicators[0] = "Ratio of GDP per Capita and CO2 Emissions";
			
			barGraphDataset = graph.createBar(getValueArray(), getIndicators(), getStartYear());
			lineGraphDataset = graph.createLine(getValueArray(), getIndicators(), getEndYear());
			scatterGraphDataset = graph.createScatter(getValueArray(), getIndicators(), getEndYear());
			reportGraphDataset = graph.createReport(getValueArray(), getIndicators(), getEndYear(), getAnalysis(), getStartYear());

		}
		else if (analysis.equals(("Alternative and Nuclear Energy vs GDP per Capita").toLowerCase()))
		{
			indicators = new String[2];
			indicators[0] =  "Alternative and nuclear energy (% of total energy use)";
			indicators[1] = "GDP per capita (current US$)";
			xAxis = "% of total energy use";
			yAxis = "current US$";
			valueArray = performAnnualChange();
			barGraphDataset = graph.createBar(getValueArray(), getIndicators(), getStartYear());
			lineGraphDataset = graph.createLine(getValueArray(), getIndicators(), getEndYear());
			scatterGraphDataset = graph.createScatter(getValueArray(), getIndicators(), getEndYear());
			reportGraphDataset = graph.createReport(getValueArray(), getIndicators(), getEndYear(), getAnalysis(), getStartYear());

		}		
		
		else if (analysis.equals(("Government Expenditure on Education vs Research and development expenditure").toLowerCase()))
		{
			indicators = new String[2];

			indicators[0] =  "Government expenditure on education, total (% of GDP)";
			indicators[1] = "Research and development expenditure (% of GDP)"; ;//need
			xAxis = "% of GDP";
			yAxis = "% of GDP";
			valueArray = performAnnualChange();
			barGraphDataset = graph.createBar(getValueArray(), getIndicators(), getStartYear());
			lineGraphDataset = graph.createLine(getValueArray(), getIndicators(), getEndYear());
			scatterGraphDataset = graph.createScatter(getValueArray(), getIndicators(), getEndYear());
			reportGraphDataset = graph.createReport(getValueArray(), getIndicators(), getEndYear(), getAnalysis(), getStartYear());

		}		
		
//		else if (analysis.equals("Government expenditure on education"))
//		{
//			indicators = new String[1];
//
//			indicators[0] =  "Government expenditure on education, total (% of GDP)";
//			this.barGraphDataset = graph.createBar(this.performAnnualChange(), this.getIndicators(), this.getStartYear());
//			this.lineGraphDataset = graph.createLine(this.performAnnualChange(), this.getIndicators(), this.getStartYear());
//		}	
		else if (analysis.equals(("Air Pollution Mean Annual Exposure vs Forest Area").toLowerCase()))
		{
			indicators = new String[2];

			indicators[0] =  "Government expenditure on education, total (% of GDP)";
			indicators[1] = "Forest area (% of land area)";
			xAxis = "% of GDP";
			yAxis = "% of land area";
			valueArray = performAnnualChange();
			barGraphDataset = graph.createBar(getValueArray(), getIndicators(), getStartYear());
			lineGraphDataset = graph.createLine(getValueArray(), getIndicators(), getEndYear());
			scatterGraphDataset = graph.createScatter(getValueArray(), getIndicators(), getEndYear());
			reportGraphDataset = graph.createReport(getValueArray(), getIndicators(), getEndYear(), getAnalysis(), getStartYear());

		}	
		else if (analysis.equals(("Surface Area vs Agricultural Land vs Agricultural Irrigated Land").toLowerCase()))
		{
			indicators = new String[3];

			indicators[0] =  "Surface area (sq. km)";
			indicators[1] = "Agricultural land (% of land area)";
			indicators[2] = "Agricultural irrigated land (% of total agricultural land)";
			xAxis = "sq. km";
			yAxis = "% of land area";
			valueArray = performAnnualChangeSQKM();
			barGraphDataset = graph.createBar(getValueArray(), getIndicators(), getStartYear());
			lineGraphDataset = graph.createLine(getValueArray(), getIndicators(), getEndYear());
			scatterGraphDataset = graph.createScatter(getValueArray(), getIndicators(), getEndYear());
			reportGraphDataset = graph.createReport(getValueArray(), getIndicators(), getEndYear(), getAnalysis(), getStartYear());

		}	
		else if (analysis.equals(("Lending Interest rates vs Real Interest Rates vs Difference betweeen the two").toLowerCase()))
		{
			indicators = new String[2];
			indicators[0] =  "Lending interest rate (%)";
			indicators[1] = "Real interest rate (%)";
			xAxis = "%";
			yAxis = "%";
			ArrayList<HashMap<Integer, Double>> temp = performAnnualChange();
			temp.add(performDifference());
			indicators = new String[3];
			indicators[0] =  "Lending interest rate (%)";
			indicators[1] = "Real interest rate (%)";
			indicators[2] = "Difference between the two";
			barGraphDataset = graph.createBar(temp, getIndicators(), getStartYear());
			lineGraphDataset = graph.createLine(temp, getIndicators(), getEndYear());		
			scatterGraphDataset = graph.createScatter(temp, getIndicators(), getEndYear());
			reportGraphDataset = graph.createReport(temp, getIndicators(), getEndYear(), getAnalysis(), getStartYear());

		}	
		else if (analysis.equals(("Population Ages 15-64 vs School enrollment, secondary").toLowerCase()))
		{
			indicators = new String[2];

			indicators[0] =  "Population ages 15-64 (% of total population)";
			indicators[1] = "School enrollment, secondary (% gross)";
			xAxis = "% of total population";
			yAxis = "% gross";
			valueArray = performAnnualChange();
			barGraphDataset = graph.createBar(getValueArray(), getIndicators(), getStartYear());
			lineGraphDataset = graph.createLine(getValueArray(), getIndicators(), getEndYear());
			scatterGraphDataset = graph.createScatter(getValueArray(), getIndicators(), getEndYear());
			reportGraphDataset = graph.createReport(getValueArray(), getIndicators(), getEndYear(), getAnalysis(), getStartYear());

		}	
		else if (analysis.equals(("Fuel exports vs GDP").toLowerCase()))
		{
			indicators = new String[2];

			indicators[0] =  "Fuel exports (% of merchandise exports)";
			indicators[1] = "GDP (current US$)";
			xAxis = "% of merchandise exports";
			yAxis = "current US$";
			valueArray = performAnnualChange();
			barGraphDataset = graph.createBar(getValueArray(), getIndicators(), getStartYear());
			lineGraphDataset = graph.createLine(getValueArray(), getIndicators(), getEndYear());
			scatterGraphDataset = graph.createScatter(getValueArray(), getIndicators(), getEndYear());
			reportGraphDataset = graph.createReport(getValueArray(), getIndicators(), getEndYear(), getAnalysis(), getStartYear());

		}	
		
	}
	
	
	// RETURN METHODS
	public HashMap<String, String> countryToAcronym()
	{
		HashMap<String, String> countriesToAcronym = new HashMap<String, String>();
		countriesToAcronym.put("Canada", "CAN");
		countriesToAcronym.put("United States", "USA");
		countriesToAcronym.put("Australia", "AUS");
		countriesToAcronym.put("Belgium", "BEL");
		countriesToAcronym.put("Greece", "GRC");



		return countriesToAcronym;
	}
	
	
//	public HashMap<String, String> indicatorForAnalysis()
//	{
//		HashMap<String, String> indicatorForAnalysis = new HashMap<String, String>();
//		indicatorForAnalysis.put("Total Population", "Total Population");
//		indicatorForAnalysis.put("Alternative and Nuclear Energy", "Total Population");
//
//
//		
//		
//	}
	
		// GETTER METHODS
	public String[] getIndicators() {
		return indicators;
	}
	public String getEndYear() {
		return endYear;
	}
	

		public String getAnalysis() {
		return analysis;
	}

	public String getStartYear(){
		return startYear;
	}
	public ArrayList<HashMap<Integer, Double>> getValueArray() {
		return valueArray;
	}
	
	public String getXAxis() {
		return xAxis;
	}
	public String getYAxis() {
		return yAxis;
	}
	
	// DATA ANALYSIS METHODS
	public ArrayList<HashMap <Integer, Double>> performAnnualChange() {
		ArrayList<HashMap <Integer, Double>> dataValues = new ArrayList<HashMap <Integer, Double>>();
		
		FakeFetch proxy = new Proxy();
		
		for (int i = 0; i < indicators.length; i++) {
			dataValues.add(proxy.request(new Data(country, indicators[i], startYear, endYear)));
		}
		
		return dataValues;
	}
	
	public ArrayList<HashMap <Integer, Double>> performRatio(){
		ArrayList<HashMap <Integer, Double>> dataValues = new ArrayList<HashMap <Integer, Double>>();
		
		FakeFetch proxy = new Proxy();
		
		for (int i = 0; i < indicators.length; i++) {
			dataValues.add(proxy.request(new Data(country, indicators[i], startYear, endYear)));
		}
		
		//now to perform analysis
		HashMap<Integer, Double> ratio = new HashMap<Integer, Double>();
		
		Context context = new Context(new RatioAnalysis());
		for (int i = 0; i < dataValues.get(0).size(); i++) {
			int currYear = Integer.parseInt(startYear) + i;
			
			double[] valuesToSend = new double[2];
			valuesToSend[0] = dataValues.get(0).get(currYear);
			valuesToSend[1] = dataValues.get(1).get(currYear);
			context.setValuesForRatio(valuesToSend);
			ratio.put(currYear, context.execute());
		}
		
		dataValues = new ArrayList<HashMap <Integer, Double>>();
		dataValues.add(ratio);
		
		return dataValues;
		
		
		
	}
	
	public HashMap <Integer, Double> performDifference() {
		ArrayList<HashMap <Integer, Double>> dataValues = new ArrayList<HashMap <Integer, Double>>();
		
		FakeFetch proxy = new Proxy();
		
		for (int i = 0; i < indicators.length; i++) {
			dataValues.add(proxy.request(new Data(country, indicators[i], startYear, endYear)));
		}
		
		//now to perform analysis
		HashMap<Integer, Double> difference = new HashMap<Integer, Double>();
		
		Context context = new Context(new DifferenceAnalysis());
		for (int i = 0; i < dataValues.get(0).size(); i++) {
			int currYear = Integer.parseInt(startYear) + i;
			
			double[] valuesToSend = new double[2];
			valuesToSend[0] = dataValues.get(0).get(currYear);
			valuesToSend[1] = dataValues.get(1).get(currYear);
			context.setValuesForRatio(valuesToSend);
			difference.put(currYear, context.execute());
		}
		

		return difference;
		
		
	}
	
	public ArrayList<HashMap <Integer, Double>> performAnnualChangeSQKM() {
		ArrayList<HashMap <Integer, Double>> dataValues = new ArrayList<HashMap <Integer, Double>>();
		
		FakeFetch proxy = new Proxy();
		dataValues.add(proxy.request(new Data(country, indicators[0], startYear, endYear)));
		dataValues.add(proxy.request(new Data(country, indicators[1], startYear, endYear), dataValues));
		dataValues.add(proxy.request(new Data(country, indicators[2], startYear, endYear)));
		
		return dataValues;
	}
	
	

}
