package dataForGraphs;

import java.util.ArrayList;

import java.util.HashMap;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.Year;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;


public class GraphCreation {

	
	// Create bar graph for an analysis type
	public DefaultCategoryDataset createBar(ArrayList<HashMap<Integer, Double>> yearlyData, String[] indicators, String startYear) {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		
		for(int i = 0; i < yearlyData.size(); i++) {
			for(int j = 0; j < yearlyData.get(i).size(); j++) {
				int currYear = Integer.parseInt(startYear) + j;
				dataset.setValue(yearlyData.get(i).get(currYear), indicators[i], Integer.toString(currYear));
			}
		}
		return dataset;
	}
	
	// Create scatter graph for an analysis type
	public XYSeriesCollection createLine(ArrayList<HashMap<Integer, Double>> yearlyData, String[] indicators, String endYear) {
		XYSeriesCollection dataset = new XYSeriesCollection();
		for(int i = 0; i < yearlyData.size(); i++) {
			XYSeries series = new XYSeries(indicators[i]);
			for(int j = 0; j < yearlyData.get(i).size(); j++) {
				int currYear = Integer.parseInt(endYear) - j;
				series.add(currYear, yearlyData.get(i).get(currYear));
			}
			dataset.addSeries(series);
		}
		return dataset;
	}
	
	// Create scatter graph for an analysis type
		public TimeSeriesCollection createScatter(ArrayList<HashMap<Integer, Double>> yearlyData, String[] indicators, String endYear) {
			TimeSeriesCollection dataset = new TimeSeriesCollection();
			for(int i = 0; i < yearlyData.size(); i++) {
				TimeSeries series = new TimeSeries(indicators[i]);
				for(int j = 0; j < yearlyData.get(i).size(); j++) {
					int currYear = Integer.parseInt(endYear) - j;
					series.add(new Year(currYear), yearlyData.get(i).get(currYear));
				}
				dataset.addSeries(series);
			}
			return dataset;
		}
		

		public String createReport(ArrayList<HashMap<Integer, Double>> yearlyData, String[] indicators, String endYear, String analysis, String startYear) {
			String dataset;
			

	
			String header = analysis + "\n" + "==============================\n";
			int currYear = Integer.parseInt(endYear);
			
			int size = yearlyData.size();
			
//			for(int i = 0; i < yearlyData.size(); i++) {
//				
//				for(int j = 0; j < yearlyData.get(i).size(); j++) {
//					String year = Integer.toString(currYear);
//					header+= "Year " + currYear + ":\n";
//					
//					System.out.println(indicators[i] + " year" + currYear + " data " + yearlyData.get(i).get(currYear));
//				
//					currYear--;
//
//				}
//				currYear = Integer.parseInt(endYear);
//
//			}
			
			for (int i= currYear; i >= Integer.parseInt(startYear); i--) //yearlyData.get(0).size is basically number of years
			{
				header+= "Year " + i + ":\n";
				for (int j=0; j< yearlyData.size(); j++ ) //so for number of indicators basically
				{
					header +=  "\t"  + indicators[j] + "=> " + yearlyData.get(j).get(i) + "\n";
				}
				
				
			}

			return header;
		}
}
