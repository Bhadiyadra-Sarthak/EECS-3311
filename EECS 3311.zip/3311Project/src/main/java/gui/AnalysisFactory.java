package gui;

import java.util.Vector;



public class AnalysisFactory {

	public Vector<String> addAnalysis(String analysisName, Vector<String> analysisList){
		
		if(analysisName.equalsIgnoreCase("Total Population vs Energy Use")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		else if (analysisName.equalsIgnoreCase("Ratio of GDP per Capita and CO2 Emissions")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		else if (analysisName.equalsIgnoreCase("Alternative and Nuclear Energy vs GDP per Capita")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		else if (analysisName.equalsIgnoreCase("Government Expenditure on Education vs Research and Development Expenditure")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		else if (analysisName.equalsIgnoreCase("Government Expenditure on Education")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		else if (analysisName.equalsIgnoreCase("Air Pollution Mean Annual Exposure vs Forest Area")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		else if (analysisName.equalsIgnoreCase("Surface Area vs Agricultural Land vs Agricultural Irrigated Land")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		else if (analysisName.equalsIgnoreCase("Lending Interest rates vs Real Interest Rates vs Difference betweeen the two")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		else if (analysisName.equalsIgnoreCase("Population Ages 15-64 vs Literacy Rate of Adults (15+)")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		else if (analysisName.equalsIgnoreCase("Fuel Exports vs GDP")) {
			analysisList.add(analysisName);
			return analysisList;
		}
		
		else {
			return null;
		}
		
	}
}
