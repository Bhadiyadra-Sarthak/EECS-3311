package gui;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Vector;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class setCountries {
	Vector<String> countryNames = new Vector<String>();
	HashMap<String, String> countriesToAcronym = new HashMap<String, String>();
	
	public setCountries()  {
		
		String[] countries = Locale.getISOCountries();
		
		for(int i = 0; i < countries.length; i++) { 
			
			String country = countries[i];
			Locale locale = new Locale("en", country);
         
			// Get the country name by calling getDisplayCountry()
			String countryName = locale.getDisplayCountry();
			countryNames.add(countryName);
			// Printing the country name on the console
         //System.out.println(i+1 + " : " + countryName +  " idk " + country);
         countriesToAcronym.put(countryName, country);
		}		

	}
	
	public Vector<String> getCountries(){
		return countryNames;
	}
	
	public boolean countriesInDropDown(String country)
	{
		return countryNames.contains(country);
	}
	
	public String returnAcronym(String country) {
		return countriesToAcronym.get(country);
	}
	
	public boolean checkIfCountryAllowed(String country)
	{
		boolean truth = false;
		JSONParser jsonparser = new JSONParser();
		FileReader reader = null;
		try {
			reader = new FileReader("countriesAllowed.json");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Object obj = null;
				try {
					obj = jsonparser.parse(reader);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (org.json.simple.parser.ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			// TODO Auto-generated catch block
	
		JSONObject data = (JSONObject)obj;
		
		JSONArray countries = (JSONArray)data.get("countries");
		
		
		for (int i=0; i< countries.size(); i++)
		{
			JSONObject currentCountry = (JSONObject)countries.get(i);
			String countryFromJson = (String) currentCountry.get("name");
			if (countryFromJson.equals(country))
			{
				truth = true;
				return truth;
			
			}
			//System.out.println(countryFromJson);
		}
		
	return truth;	
	}
	
	
	public static void main(String[] args)
	{
		setCountries test = new setCountries();
		System.out.println(test.checkIfCountryAllowed("Cdd"));
		
	}
	
}
