package gui;

import java.awt.BasicStroke; 
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.text.AbstractDocument.Content;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.renderer.xy.XYSplineRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.time.Year;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import dataForGraphs.BuilderForGraphs;

import org.jfree.chart.JFreeChart;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.*;   


/***
 * Generates the GYU, implementing singleton design so only one instance of the GUI can be created
 *
 */
public class Maingui extends JFrame{
	
	private String[] snapShotOfExecute = new String[4];
	private JPanel charts = new JPanel();
	private BuilderForGraphs jonathan;
	public ChartPanel removeScatter = null;
	public ChartPanel removeBar = null;
	public ChartPanel removeLine = null;
	public JScrollPane removeReport = null;
	private static final long serialVersionUID = 1L;
	
	private static Maingui instance;
	
	public static Maingui getInstance() {
		if (instance == null) 
			instance = new Maingui();
		
		return instance;
	}
	
	public Maingui() {
		
		super("World Bank Data Analysis");
		setCountries settingCountries = new setCountries();

		JLabel pickCountry = new JLabel("Select a Country for Analysis: ");
		Vector<String> countryNames = settingCountries.getCountries();	
//		Vector<String> countryNames = new Vector<String>();
//		countryNames.add("Canada");
//		countryNames.add("United States");
//		countryNames.add("Australia");
//		countryNames.add("Belgium");
//		countryNames.add("Greece");

		countryNames.sort(null);
		
		
		final JComboBox<String> countryList = new JComboBox<String>(countryNames);
		
		JLabel from = new JLabel(" From: ");
		JLabel to = new JLabel("To: ");
		Vector<String> years = new Vector<String>();
		for (int i = 2018; i >= 1995; i--) {
			years.add(Integer.toString(i));
		}
		
		final JComboBox<String> fromList = new JComboBox<String>(years);
		final JComboBox<String> toList = new JComboBox<String>(years);
		
		JButton execute  = new JButton("Execute");

		
		
		JLabel viewslabel = new JLabel("                        Available Views: ");
		
		Vector<String> viewsNames = new Vector<String>();
		viewsNames.add("Scatter Graph");
		viewsNames.add("Line Graph");
		viewsNames.add("Bar Graph");
		viewsNames.add("Report");
		final JComboBox<String> viewsList = new JComboBox<String>(viewsNames);
		JButton addView = new JButton("add");
		JButton removeView = new JButton("remove");
		

		JLabel analysisMethodLabel = new JLabel("                           Choose Analysis Method: ");
		
		Vector<String> analysisMethodNames = new Vector<String>();
		AnalysisFactory analysisFactory = new AnalysisFactory();
		analysisFactory.addAnalysis("Lending Interest rates vs Real Interest Rates vs Difference betweeen the two", analysisMethodNames);
		analysisFactory.addAnalysis("Government Expenditure on Education vs Research and Development Expenditure", analysisMethodNames);
		analysisFactory.addAnalysis("Air Pollution Mean Annual Exposure vs Forest Area", analysisMethodNames);

		analysisFactory.addAnalysis("Ratio of GDP per Capita and CO2 Emissions", analysisMethodNames);

		
		analysisFactory.addAnalysis("Total Population vs Energy Use", analysisMethodNames);
		analysisFactory.addAnalysis("Alternative and Nuclear Energy vs GDP per Capita", analysisMethodNames);
		analysisFactory.addAnalysis("Surface Area vs Agricultural Land vs Agricultural Irrigated Land", analysisMethodNames);
		analysisFactory.addAnalysis("Population Ages 15-64 vs School enrollment, secondary", analysisMethodNames);
		analysisFactory.addAnalysis("Fuel Exports vs GDP", analysisMethodNames);

		final JComboBox<String> analysisMethodList = new JComboBox<String>(analysisMethodNames);
		
		
		JPanel bar = new JPanel();
		bar.add(pickCountry);
		bar.add(countryList);
		bar.add(from);
		bar.add(fromList);
		bar.add(to);
		bar.add(toList);

		bar.add(viewslabel);
		bar.add(viewsList);
		bar.add(addView);
		bar.add(removeView);
		bar.add(analysisMethodLabel);
		bar.add(analysisMethodList);
		bar.add(execute);
		
		
	    execute.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent e){  
	    	            runExecution(analysisMethodList, countryList, viewsList, fromList, toList);
	    	        }  
	    	    }); 
	    addView.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent e){  
	    	            addExecute(viewsList);
	    	        }  
	    	    });
	    removeView.addActionListener(new ActionListener(){  
	    	public void actionPerformed(ActionEvent e){  
	    	            removeExecute(viewsList);
	    	        }  
	    	    });
	    
	    
		charts.setLayout(new GridLayout(2,0));
		getContentPane().add(charts, BorderLayout.WEST);
		getContentPane().add(bar, BorderLayout.SOUTH);

	
		
	}
	
	
	private void addExecute(JComboBox viewsList) {
		if (viewsList.getSelectedItem().toString().equalsIgnoreCase("Scatter Graph")) {
			createScatter(charts);
		}
		else if ((viewsList.getSelectedItem().toString().equalsIgnoreCase("Line Graph"))) {
			createLine(charts);
		}
		else if ((viewsList.getSelectedItem().toString().equalsIgnoreCase("Bar Graph"))) {
			createBar(charts);
		}
		else if ((viewsList.getSelectedItem().toString().equalsIgnoreCase("Report"))) {
			createReport(charts);
		}
		else {
			System.out.println("error occured");
		}
		getContentPane().revalidate();
	}
	
	private void removeExecute(JComboBox viewsList) {
		String typeOfGraph = viewsList.getSelectedItem().toString();
		Component[] components = charts.getComponents();
		if (typeOfGraph.equalsIgnoreCase("Scatter Graph")){
			for(Component component: components) {
				if(removeScatter == component) {
					charts.remove(removeScatter);
				}
			}
		}
		else if ((typeOfGraph.equalsIgnoreCase("Line Graph"))) {
			for(Component component: components) {
				if(removeLine == component) {
					charts.remove(removeLine);
				}
			}
		}
		else if ((typeOfGraph.equalsIgnoreCase("Bar Graph"))) {
			for(Component component: components) {
				if(removeBar == component) {
					charts.remove(removeBar);
				}
			}
		}
		else if ((typeOfGraph.equalsIgnoreCase("Report"))) {
			for(Component component: components) {
				if(removeReport == component) {
					charts.remove(removeReport);
				}
			}
		}
		else {
			System.out.println("error occured");
		}
		getContentPane().revalidate();
	}
	
	public void removeAll() {
		Component[] components = charts.getComponents();
		for(Component component: components) {
			if(removeScatter == component) {
				charts.remove(removeScatter);
			}
			if(removeLine == component) {
				charts.remove(removeLine);
			}
			if(removeBar == component) {
				charts.remove(removeBar);
			}
			if(removeReport == component) {
				charts.remove(removeReport);
			}
		}
		getContentPane().revalidate();
	}
	
	
	
	
	
	public void createScatter(JPanel charts) {
		if (removeScatter == null) {
			TimeSeriesCollection dataset = jonathan.generateScatterGraph();
	
			XYPlot plot = new XYPlot();
			XYItemRenderer itemrenderer1 = new XYLineAndShapeRenderer(false, true);
	
			plot.setDataset(dataset);
			plot.setRenderer(itemrenderer1);
			DateAxis domainAxis = new DateAxis(jonathan.getYAxis());
			plot.setDomainAxis(domainAxis);
			plot.setRangeAxis(new NumberAxis("Year"));
	
	
			plot.mapDatasetToRangeAxis(0, 0);
	
			JFreeChart scatterChart = new JFreeChart(snapShotOfExecute[1],
					new Font("Serif", java.awt.Font.BOLD, 18), plot, true);
	
			ChartPanel chartPanel = new ChartPanel(scatterChart);
			chartPanel.setPreferredSize(new Dimension(955, 500));
			chartPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
			chartPanel.setBackground(Color.white);
			charts.add(chartPanel);
			removeScatter = chartPanel;
		}
	}
	public void createBar(JPanel charts) {
		if (removeBar == null) {
			DefaultCategoryDataset dataset = jonathan.generateBarGraph();
	
			
			CategoryPlot barGraph = new CategoryPlot();
			
			BarRenderer barRenderer1 = new BarRenderer();
			
			barGraph.setDataset(0, dataset);
			barGraph.setRenderer(0, barRenderer1);
			
			CategoryAxis domain = new CategoryAxis("");
			barGraph.setDomainAxis(domain);
			barGraph.setRangeAxis(new NumberAxis(jonathan.getYAxis()));
			barGraph.setRangeAxis(1, new NumberAxis("Year"));
			
			barGraph.mapDatasetToRangeAxis(0, 0);
			barGraph.mapDatasetToRangeAxis(1, 1);
			
			JFreeChart barGrapher = new JFreeChart(snapShotOfExecute[1], new Font("serif", java.awt.Font.BOLD, 18), barGraph, true);
			
			ChartPanel barchartPanel = new ChartPanel(barGrapher);
			barchartPanel.setPreferredSize(new Dimension(955, 500));
			barchartPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
			barchartPanel.setBackground(Color.white);
			charts.add(barchartPanel);
			removeBar = barchartPanel;
		}
	}
	public void createLine(JPanel charts) {
		if (removeLine == null) {
			XYSeriesCollection dataset = jonathan.generateLineGraph();
	
			JFreeChart chart = ChartFactory.createXYLineChart(snapShotOfExecute[1], jonathan.getYAxis(), jonathan.getXAxis(), dataset,
					PlotOrientation.VERTICAL, true, true, false);
	
			XYPlot plot = chart.getXYPlot();
	
			XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
			renderer.setSeriesPaint(0, Color.red);
			renderer.setSeriesStroke(0, new BasicStroke(2.0f));
	
			plot.setRenderer(renderer);
			plot.setBackgroundPaint(Color.white);
	
			plot.setRangeGridlinesVisible(true);
			plot.setRangeGridlinePaint(Color.BLACK);
	
			plot.setDomainGridlinesVisible(true);
			plot.setDomainGridlinePaint(Color.BLACK);
	
			chart.getLegend().setFrame(BlockBorder.NONE);
	
			chart.setTitle(
					new TextTitle(snapShotOfExecute[1], new Font("Serif", java.awt.Font.BOLD, 18)));
	
			ChartPanel linechartPanel = new ChartPanel(chart);
			linechartPanel.setPreferredSize(new Dimension(955, 500));
			linechartPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
			linechartPanel.setBackground(Color.white);
			charts.add(linechartPanel);
			removeLine = linechartPanel;
		}
	}
	public void createReport(JPanel charts) {
		if (removeReport == null) {
			String reportMessage = jonathan.generateReport();
			JTextArea report = new JTextArea();
			report.setEditable(true);
			report.setPreferredSize(new Dimension(955, 500));
			report.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
			
			
			report.setText(reportMessage);
			JScrollPane outputScrollPane = new JScrollPane(report);
			charts.add(outputScrollPane);
			removeReport = outputScrollPane;
		}
		
	}
	
	public void runExecution(JComboBox<String> analysisMethodList, JComboBox<String> countryList, JComboBox<String> viewsList, JComboBox<String> fromList, JComboBox<String> toList){
		snapShotOfExecute[0] = countryList.getSelectedItem().toString();
		
		snapShotOfExecute[1] = analysisMethodList.getSelectedItem().toString();
		snapShotOfExecute[2] = fromList.getSelectedItem().toString();
		snapShotOfExecute[3] = toList.getSelectedItem().toString();
		
		if  (inDatabase(snapShotOfExecute[0]))
		{
			jonathan = new BuilderForGraphs(snapShotOfExecute[0], snapShotOfExecute[1], snapShotOfExecute[2], snapShotOfExecute[3]);

		}
		else
		{
			JOptionPane.showMessageDialog(null, "Not in Database, no data fetching is available for selected country", "Database Error", JOptionPane.INFORMATION_MESSAGE);

		}
		//jonathan = new BuilderForGraphs(snapShotOfExecute[0], snapShotOfExecute[1], snapShotOfExecute[2], snapShotOfExecute[3]);
	
		removeAll();
		
	}
	
	/*
	 * Returns true if in the database
	 */
	public boolean inDatabase(String country) {

		setCountries settingCountries = new setCountries();

		boolean allowed = settingCountries.checkIfCountryAllowed(country);

		return allowed;
	}
	
	public void initializeGraphData(String country, String analysis, String startYear, String endYear) {
		jonathan = new BuilderForGraphs(country, analysis, startYear, endYear);
		
		snapShotOfExecute[0] = country;
		snapShotOfExecute[1] = analysis;
		snapShotOfExecute[2] = startYear;
		snapShotOfExecute[3] = endYear;
	}
//	public static void main(String[] args) {
//		JFrame test = Maingui.getInstance();
//		test.setSize(1000,1000);
//		test.pack();
//		test.setVisible(true);
//	
//	}
}
