package analysis;


/***
 * Class gets a count of number of years and total addition of values as a integer array, and performs a division.
 *
 */
public class AvgYearsAnalysis extends Strategy {

	@Override
	public double doAlgorithm(Context context) {
		int getCount = context.getCountAndValues()[0];
		int getValues = context.getCountAndValues()[1];//assuming values are added to int[1] +=
		
		return getValues/getCount;
	}
	
}
