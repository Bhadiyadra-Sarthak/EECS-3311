package analysis;

/***
 *Class designed so that the family of algorithms could be called through, receiving inputs from fetched data as integer arrays.
 *
 *
 */
public class Context {
	private Strategy strategy;
	private double[] valuesForRatio;
	private int[] dateAndValue;
	private int[] dateAndValue2;
	private int[] countAndValues; //For avg years, send count and total added values for selected years
	
	public Context (Strategy strategy)
	{
		this.strategy = strategy;
	}
	
	public void setStrategy(Strategy strategy)
	{
		this.strategy = strategy;
	}
	public void setDateAndValue(int[] list1)
	{
		dateAndValue = list1;
	}
	public void setValuesForRatio(double[] list)
	{
		this.valuesForRatio = list;
	}
	
	public double[] getValuesForRatio() {
		return this.valuesForRatio;
	}
	public void setDateAndValue(int[]  list1, int[]  list2)
	{
		dateAndValue = list1;
		dateAndValue2 = list2;
	}
	
	public double execute() {
		return strategy.doAlgorithm(this);
	}
	
	public int[] getdateAndValue() {
		return dateAndValue;
	}
	public int[] getdateAndValue2() {
		return dateAndValue2;
	}
	
	public int[] getCountAndValues() {
		return countAndValues;
	}
}
