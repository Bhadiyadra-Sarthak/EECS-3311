package analysis;
/***
 * Testing class to test seperate analysis strategies
 ***/
public class TestAnalysis {
	
	public static void main(String[] args)
	{
		Context context = new Context(new RatioAnalysis());
		int[] dateAndValue1 = {1999,55000};
		int[] dateAndValue2 = {2010,2000};
		context.setDateAndValue(dateAndValue1,dateAndValue2);
		System.out.println("Date 1 = " + dateAndValue1[0] + " Value 1 = " + dateAndValue1[1]);
		System.out.println("Date 2 = " + dateAndValue2[0] + " Value 2 = " + dateAndValue2[1]);

		System.out.println("Ratio calculation of value 1 and value 2 is " + context.execute());
		context.setStrategy(new DifferenceAnalysis());
		System.out.println("Difference analysis of value 1 and value 2 is " + context.execute());
		context.setStrategy(new AvgYearsAnalysis());
		System.out.println("Average analysis over years " + "WIP" );
	}
	
}
