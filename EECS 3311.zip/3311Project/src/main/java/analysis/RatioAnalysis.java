package analysis;

import java.math.BigDecimal;
import java.math.RoundingMode;

/***
 * Class performs a division on a set of 2 values to get a ratio
 *
 */
public class RatioAnalysis extends Strategy{

	@Override
	public double doAlgorithm(Context context) {

		double firstValue = context.getValuesForRatio()[0];
		double secondValue = context.getValuesForRatio()[1];
		
		double result = firstValue / secondValue;

		BigDecimal bd = new BigDecimal(result).setScale(2, RoundingMode.HALF_UP);

        return bd.doubleValue();

		}
		

		
}
	
	

