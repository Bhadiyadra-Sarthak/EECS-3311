package analysis;

/***
 * Abstract class that specific strategies inherit from to perform own calculations
 *
 */
public abstract class Strategy {
	public abstract double doAlgorithm(Context context);
}
