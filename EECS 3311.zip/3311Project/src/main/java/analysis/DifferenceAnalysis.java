package analysis;

/***
 * Class returns difference of two values.
 *
 */
public class DifferenceAnalysis  extends Strategy{

	@Override
	public double doAlgorithm(Context context) {
		double firstValue = context.getValuesForRatio()[0];
		double secondValue = context.getValuesForRatio()[1];
		
		return firstValue - secondValue;
	}
	
}
