package login;

public class Admin {
	private order order;
	
	public Admin(order order)
	{
		this.order = order;
	}
	
	public boolean execute() {
		return this.order.execute();
	}
}
