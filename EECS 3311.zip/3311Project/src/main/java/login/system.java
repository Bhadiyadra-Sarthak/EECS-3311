package login;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFrame;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import gui.Maingui;

public class system {

	public boolean checkIfDatabase(String user, String pass) {
		boolean truth = false;
		JSONParser jsonparser = new JSONParser();
		FileReader reader = null;
		try {
			reader = new FileReader("logins.json");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Object obj = null;
		try {
			obj = jsonparser.parse(reader);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JSONObject data = (JSONObject)obj;
		
		JSONArray logins = (JSONArray)data.get("logins");
		
		
		for (int i=0; i< logins.size(); i++)
		{
			JSONObject currentUser = (JSONObject)logins.get(i);
			String usernameFromLogins = (String) currentUser.get("username");
			String passwordFromLogins = (String) currentUser.get("password");

			if (usernameFromLogins.equals(user) && passwordFromLogins.equals(pass))
			{
				//in login
				
				truth=true;
				break;
			}
		}
		
		
		return truth;
	}
}
