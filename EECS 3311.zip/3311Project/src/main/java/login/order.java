package login;

public class order implements command{
	private system system;
	private String user;
	private String password;
	
	public order(system system, String user, String pass)
	{
		this.system = system;
		this.user = user;
		this.password = pass;
	}
	
	
	
	public boolean execute() {
		return this.system.checkIfDatabase(user, password);
	}

}
