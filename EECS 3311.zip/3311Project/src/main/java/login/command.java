package login;

public interface command {
	public abstract boolean execute();
}
