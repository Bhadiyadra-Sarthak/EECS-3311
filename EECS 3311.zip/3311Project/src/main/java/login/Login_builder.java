package login;
/*
 * This is the GUI class of the login window it opens a new login window for users to login
 */
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import org.json.simple.*;
import org.json.simple.parser.*;

import gui.Maingui;
public class Login_builder {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private JTextField user;
	private JTextField pass; 



	public JFrame getFrame() {
		return this.frame;
	}
	
	public Login_builder() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize()  {
		frame = new JFrame();
		frame.setBounds(100, 100, 390, 171);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Submit!");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e)  {
				String username = user.getText();
				String password = pass.getText();
				
			
				system system = new system();
				
				order order = new order(system, username, password);
				Admin admin = new Admin(order);
				boolean login = admin.execute();
				
				if (login == true)
				{
					frame.setVisible(false);
					JFrame test = Maingui.getInstance();
					test.setSize(1000,1000);
					test.pack();
					test.setVisible(true);
				}
				
			
				else if (login == false)
				{
					JOptionPane.showMessageDialog(null, "Wrong username or password", "Incorrect Credentials", JOptionPane.INFORMATION_MESSAGE);
					frame.setVisible(false);

				}
			

			}
		});
		btnNewButton.setBounds(121, 91, 87, 30);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setBounds(7, 16, 63, 20);
		frame.getContentPane().add(lblNewLabel);
		
		user = new JTextField();
		user.setBounds(74, 16, 263, 20);
		frame.getContentPane().add(user);
		user.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Password:");
		lblNewLabel_1.setBounds(7, 47, 63, 22);
		frame.getContentPane().add(lblNewLabel_1);
		
		pass = new JPasswordField();
		pass.setBounds(74, 47, 263, 20);
		frame.getContentPane().add(pass);
	}
}
